package CasosdeUso;

import java.util.List;

import aplicacao.pack2.FachadaAlunoUniversitario;
import aplicacao.pack2.IAlunoUniversitario;
import framework.pack2.Turma;

public class CancelaMateria {

	public static void main(String[] args) {

		IAlunoUniversitario a = FachadaAlunoUniversitario.getAluno(3);

		List<Turma> v = a.getTurmas();

		System.out.println("Minhas Turmas: ");
		for (Turma t : v) {
			System.out.println(t.getDisciplina());
		}
		System.out.println();

		// DAQUI PRA CIMA VEIO DO BANCO DE DADOS
		// Entrada de Dados
		System.out.println("Turma " + a.getTurma(3).getID() + " da disciplina de "
				+ a.getTurma(3).getDisciplina().getNome() + " foi cancelada!");
		a.removeTurma(3);

		System.out.println();

		// RESULTADO
		System.out.println("Minhas Turmas: ");
		v = a.getTurmas();

		for (Turma t : v) {
			System.out.println(t.getDisciplina());
		}

	}

}
