package CasosdeUso;

import aplicacao.pack2.FachadaGradeUniversitaria;
import aplicacao.pack2.IGradeUniversitaria;

public class ImprimeGrade {

	public static void main(String[] args) {
		
		//Nome do aluno para buscar a grade
		String nome = "Jorge";
		IGradeUniversitaria grade = FachadaGradeUniversitaria.getGrade(nome);
		
		
		//ALUNO GERA HISTÓRICO
		grade.gerarHistorico();
		

		

	}

}
