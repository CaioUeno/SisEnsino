package CasosdeUso;

import aplicacao.pack2.FachadaAlunoUniversitario;
import aplicacao.pack2.FachadaMateria;
import aplicacao.pack2.IAlunoUniversitario;
import aplicacao.pack2.IMateria;

public class SetaNota {

	public static void main(String[] args) {

		IAlunoUniversitario aluno = FachadaAlunoUniversitario.getAluno(2);
		IMateria materia = FachadaMateria.getMateria(6);
		
		System.out.println("Aluno " + aluno.getNome() + " com nota -> " + aluno.getNotaDisciplina(materia.getThis()));

		// BANCO DE DADOS

		// Entrada de dados
		aluno.getnotaT(aluno.getTurma(102)).setNota(10);
		System.out.println("Aluno " + aluno.getNome() + " com nota -> " + aluno.getNotaDisciplina(materia.getThis()));

		System.out.println(aluno.getNotaDisciplina(materia.getThis()));

	}

}