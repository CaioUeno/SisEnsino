package aplicacao.pack1;

import framework.pack1.IEntidadeResponsavel;

public interface IDepartamento extends IEntidadeResponsavel {

}
