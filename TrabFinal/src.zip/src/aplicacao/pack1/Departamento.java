package aplicacao.pack1;

import framework.pack1.*;
import framework.pack2.Professor;

class Departamento extends EntidadeResponsavel implements IDepartamento {

	public Departamento(String sigla, String nome, String area, Professor profResponsavel) {
		super(sigla, nome, area, profResponsavel);
	}

}
