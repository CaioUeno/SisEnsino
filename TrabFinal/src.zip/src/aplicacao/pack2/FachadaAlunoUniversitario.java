package aplicacao.pack2;

import aplicacao.pack3.CursoUniversitario;
import framework.pack1.Escola;
import framework.pack2.FachadaAluno;

public class FachadaAlunoUniversitario extends FachadaAluno{
	public static IAlunoUniversitario getAluno(int ID) {
		
		AlunoUniversitario a = null;
		if(ID==3) {
		ProfessorUniversitario Professor1 = new ProfessorUniversitario(8, "Fernando Augusto", "fAugusto@gmail.com", 
				"Física", 3000, "43899120795", "312370983", 1200, "GruFi");
		
		ProfessorUniversitario Professor2 = new ProfessorUniversitario(19, "Henrique Pedro", "fAugusto@gmail.com", 
				"Física", 3000, "13869130795", "3109376583", 1200, "GruFi");
		
		CursoUniversitario curso = new CursoUniversitario("Física", Professor1, Professor2, "ProjetoPedagogicoFísica");
		
		GradeUniversitaria gradeJoao = new GradeUniversitaria(curso);
		
		a = new AlunoUniversitario(1, "João Souza", "joao@gmail.com", 
									gradeJoao, "40293491345", "441216549", "13/11/1995", 17560, "Rua Araguaia, 340");
	
		
		Materia materia = new Materia(1, 4, "Cálculo 1", "Ementa Cáuculo 1");
		TurmaUniversidade turma = new TurmaUniversidade(3, materia, "02/03/2019", "02/07/2019");
		turma.addProfessor(Professor1);
		NotaDisciplinaUniversitario notaT = new NotaDisciplinaUniversitario(a, turma.getDisciplina(), 0);
		a.addTurma(turma, notaT);
		

		materia = new Materia(9, 4, "Programação de Computadores", "Ementa Programação de Computadores");
		turma = new TurmaUniversidade(20, materia, "02/03/2019", "02/07/2019");
		turma.addProfessor(Professor2);
		notaT = new NotaDisciplinaUniversitario(a, turma.getDisciplina(), 0);
		a.addTurma(turma, notaT);
		}
		else {
			Escola escola = new Escola("UFSCar");
			
			ProfessorUniversitario professor = new ProfessorUniversitario(1, "Valter", "valter@dc.ufscar.br", "POO", 70000.0, "45299784415", "3946215745", 30000.0, "Programação");
			escola.addProfessor(professor);
			
			CursoUniversitario curso = new CursoUniversitario("BCC", professor, professor, "Super Projeto Pedagogico");
			
			a = new AlunoUniversitario(1, "Gabriel", "gtnardy@gmail.com", new GradeUniversitaria(curso), "45299418863", "2948754618", "strng", 20000, "Rua 1");
			escola.addAluno(a);
			
			Materia materia = new Materia(1, 4, "POOA", "Grande Ementa");
			
			TurmaUniversidade turma = new TurmaUniversidade(102, materia, "", "");
			turma.setDisciplina(materia);
			turma.addAluno(a);
			turma.addProfessor(professor);
			escola.addTurma(turma);
			
			OfertaUniversitaria oferta = new OfertaUniversitaria(1);
			oferta.addTurma(turma);
			
			NotaDisciplinaUniversitario nota = new NotaDisciplinaUniversitario(a, materia, 0);
			a.addTurma(turma, nota);
		}
		
		return a;
	}
}
