package aplicacao.pack2;

import framework.pack2.Oferta;

class OfertaUniversitaria extends Oferta {

	public OfertaUniversitaria(int ID) {
		super(ID);
	}

}
