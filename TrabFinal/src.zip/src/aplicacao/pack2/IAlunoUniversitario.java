package aplicacao.pack2;

import framework.pack2.IAluno;

public interface IAlunoUniversitario extends IAluno{
	
	
}
