package aplicacao.pack2;

import java.util.HashMap;
import java.util.Map;

import framework.pack2.Disciplina;
import framework.pack2.Grade;
import framework.pack3.Curso;

class GradeUniversitaria extends Grade implements IGradeUniversitaria {

	private Map<Disciplina, Double> historico = new HashMap<Disciplina, Double>();

	public GradeUniversitaria(Curso curso) {
		super(curso);
	}

	public void addDisciplina(Disciplina disciplina) {
		this.disciplinas.add(disciplina);
		historico.put(disciplina, (double) 0);
	}

	public void removeDisciplina(Disciplina disciplina) {
		this.disciplinas.remove(disciplina);
		historico.remove(disciplina);
	}

	public void changeStatusDisciplina(Disciplina disciplina, double n) {
		historico.put(disciplina, n);
	}

	public void gerarHistorico() {
		for (Map.Entry<Disciplina, Double> pair : historico.entrySet()) {
			System.out.println(pair.getKey().getNome());
			if (pair.getValue() >= 6) {
				System.out.println("Aprovado com : " + pair.getValue());
			} else {
				System.out.println("Reprovado");
			}
			System.out.println();
		}
	}

}
