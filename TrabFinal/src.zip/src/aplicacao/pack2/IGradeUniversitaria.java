package aplicacao.pack2;

import framework.pack2.IGrade;

public interface IGradeUniversitaria extends IGrade{


}
