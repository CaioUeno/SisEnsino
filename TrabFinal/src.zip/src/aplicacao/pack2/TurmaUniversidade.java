package aplicacao.pack2;

import java.util.ArrayList;
import java.util.List;

import framework.pack2.Disciplina;
import framework.pack2.Professor;
import framework.pack2.Turma;

public class TurmaUniversidade extends Turma {

	private List<Professor> professores = new ArrayList<>();
	
	public TurmaUniversidade(int iD, Disciplina disciplina, String dataInicio, String dataFim) {
		super(iD, disciplina, dataInicio, dataFim);
	}

	public List<Professor> getProfessores() {
		return professores;
	}

	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}

	public void addProfessor(Professor professor) {
		this.professores.add(professor);
	}

	public void removeProfessor(Professor professor) {
		this.professores.remove(professor);
	}

}
