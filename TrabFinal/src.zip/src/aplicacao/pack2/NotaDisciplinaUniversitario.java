package aplicacao.pack2;

import framework.pack2.Aluno;
import framework.pack2.Disciplina;
import framework.pack2.NotaDisciplina;

class NotaDisciplinaUniversitario extends NotaDisciplina {

	public NotaDisciplinaUniversitario(Aluno aluno, Disciplina disciplina, double nota) {
		super(aluno, disciplina, nota);
	}


}
