package aplicacao.pack2;

import framework.pack2.IDisciplina;

public interface IMateria extends IDisciplina {
	
}
