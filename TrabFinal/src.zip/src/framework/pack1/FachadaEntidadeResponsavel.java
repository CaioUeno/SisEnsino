package framework.pack1;

public class FachadaEntidadeResponsavel {

}
