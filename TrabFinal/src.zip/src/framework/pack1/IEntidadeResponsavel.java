package framework.pack1;

import java.util.List;

import framework.pack2.Professor;

public interface IEntidadeResponsavel {
	
	public List<Professor> getProfessores();
	
	public void addProfessor(Professor professor);

}
