package framework.pack2;

public interface IGrade {

	public void gerarHistorico();
}
