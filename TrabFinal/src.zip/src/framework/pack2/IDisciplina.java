package framework.pack2;

public interface IDisciplina {
	
	public Disciplina getThis();
}
