package framework.pack2;

public class FachadaGrade {

}
