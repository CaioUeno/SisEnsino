package framework.pack2;

public class FachadaAluno {

}
