package framework.pack2;

import java.util.List;

public interface IAluno {
	public List<Turma> getTurmas();

	public void removeTurma(int ID);

	public Turma getTurma(int ID);
	
	public String getNome();
	
	public abstract double getNotaDisciplina(Disciplina disciplina);
	
	public NotaDisciplina getnotaT(Turma turma);
	
	public List<NotaDisciplina> getNotasTurmas();
}
